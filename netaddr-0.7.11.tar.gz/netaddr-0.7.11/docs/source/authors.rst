=======
Authors
=======

David P. D. Moss (owner and maintainer)

Released under the BSD License (see :doc:`license` for details).

